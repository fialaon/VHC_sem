/*
* Generated S-function Target for model Nonlinear. 
* This file provides access to the generated S-function target
* export file for other models.
*
* Created: Mon May 27 11:07:43 2024
*/

#ifndef RTWSFCN_Nonlinear_sf_H
#define RTWSFCN_Nonlinear_sf_H

#include "Nonlinear_sfcn_rtw\Nonlinear_sf.h"
  #include "Nonlinear_sfcn_rtw\Nonlinear_sf_private.h"

#endif
