clc, clear, close all, clear mex;

linear_bicycle_script;

nonlinear_bicycle_script;

plot_graphs;