/*
 * Generated S-function Target for model Nonlinear. 
 * This source file provides access to the generated S-function target
 * for other models.
 *
 * Created: Mon May 27 11:07:43 2024
 */

#include "Nonlinear_sf.h"
#include "Nonlinear_sfcn_rtw\Nonlinear_sf.c"
#include "Nonlinear_sfcn_rtw\Nonlinear_sf_data.c"


